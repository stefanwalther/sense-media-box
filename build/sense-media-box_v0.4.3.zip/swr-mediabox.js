/*!

* sense-media-box - Include web pages, videos, images and much more into your Qlik Sense app.
* --
* @version v0.4.3
* @link https://github.com/stefanwalther/sense-media-box
* @author Stefan Walther
* @license MIT
*/

define(["jquery","underscore","angular","./properties","./initialproperties","./lib/js/extUtils","text!./lib/partials/qsMediaBox.ng.html","text!./lib/css/main.css","./lib/directives/qsMbImage/qsMbImage","./lib/directives/qsMbVideo/qsMbVideo","./lib/directives/qsMbWebsite/qsMbWebsite","./lib/directives/qsMbHtml/qsMbHtml","./lib/directives/resize/resize"],function($,_,angular,props,initProps,extensionUtils,ngTemplate,cssContent){"use strict";return extensionUtils.addStyleToHeader(cssContent),{definition:props,initialProperties:initProps,snapshot:{canTakeSnapshot:!0},template:ngTemplate,controller:["$scope",function($scope){$scope.getImageUrl=function(){switch($scope.layout.props.mbType){case"image":return $scope.layout.props.image.source;case"imageFromLib":return $scope.layout.props.imageFromLib.url;default:return""}}}]}});